<?php
    echo 'Clase auto';
?>