<?php
    echo "clase persona";
?>